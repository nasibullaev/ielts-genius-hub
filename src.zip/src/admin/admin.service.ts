import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from '../users/schemas/user.schema';
import { UserActivity } from '../users/schemas/user-activity.schema';
import { Course } from '../courses/schemas/course.schema';
import { CourseRating } from '../courses/schemas/course-rating.schema';
import { Unit } from '../courses/schemas/unit.schema';
import { Section } from '../courses/schemas/section.schema';
import { Lesson } from '../lessons/schemas/lesson.schema';
import { QuizQuestion } from '../lessons/schemas/quiz-question.schema';
import { LevelCheck } from '../level-checker/schemas/level-check.schema';

@Injectable()
export class AdminService {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(UserActivity.name) private activityModel: Model<UserActivity>,
    @InjectModel(Course.name) private courseModel: Model<Course>,
    @InjectModel(CourseRating.name) private ratingModel: Model<CourseRating>,
    @InjectModel(LevelCheck.name) private levelCheckModel: Model<LevelCheck>,
    @InjectModel(Unit.name) private unitModel: Model<Unit>, // ✅ Add these
    @InjectModel(Section.name) private sectionModel: Model<Section>,
    @InjectModel(Lesson.name) private lessonModel: Model<Lesson>,
    @InjectModel(QuizQuestion.name)
    private quizQuestionModel: Model<QuizQuestion>,
  ) {}

  // Update the method with explicit typing:
  async getDashboardStats() {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Total users
    const totalUsers = await this.userModel.countDocuments();

    // Monthly active users
    const monthlyActiveUsers = await this.activityModel
      .distinct('userId', {
        createdAt: { $gte: thirtyDaysAgo },
      })
      .then((users) => users.length);

    // Daily active users
    const dailyActiveUsers = await this.activityModel
      .distinct('userId', {
        createdAt: { $gte: today },
      })
      .then((users) => users.length);

    // Recent activities with proper typing
    const recentActivities = await this.activityModel
      .find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('userId', 'name')
      .populate('lessonId', 'title')
      .lean<Array<any>>()
      .exec();

    // Course stats
    const courses = await this.courseModel.find().lean();
    const courseStats = await Promise.all(
      courses.map(async (course) => {
        const enrolledUsers = await this.activityModel
          .distinct('userId', {
            courseId: course._id,
          })
          .then((users) => users.length);

        return {
          courseId: course._id,
          title: course.title,
          averageRating: course.rating,
          totalRatings: course.ratingCount,
          enrolledUsers,
        };
      }),
    );

    return {
      totalUsers,
      monthlyActiveUsers,
      dailyActiveUsers,
      recentActivities: recentActivities.map((activity) => ({
        userId: activity.userId?._id || activity.userId,
        userName: activity.userId?.name || 'Unknown User',
        activityType: activity.activityType,
        lessonTitle: activity.lessonId?.title || 'Unknown Lesson',
        score: activity.quizScore || null,
        createdAt: activity.createdAt,
      })),
      courseStats,
    };
  }
  // ========== UNIT METHODS ==========
  async createUnit(createUnitDto) {
    const unit = new this.unitModel(createUnitDto);
    return unit.save();
  }

  async updateUnit(id: string, updateData) {
    return this.unitModel.findByIdAndUpdate(id, updateData, { new: true });
  }

  async deleteUnit(id: string) {
    return this.unitModel.findByIdAndDelete(id);
  }

  async getUnitsInCourse(courseId: string) {
    return this.unitModel.find({ courseId }).sort({ order: 1 });
  }

  // ========== SECTION METHODS ==========
  async createSection(createSectionDto) {
    const section = new this.sectionModel(createSectionDto);
    return section.save();
  }

  async updateSection(id: string, updateData) {
    return this.sectionModel.findByIdAndUpdate(id, updateData, { new: true });
  }

  async deleteSection(id: string) {
    return this.sectionModel.findByIdAndDelete(id);
  }

  async getSectionsInUnit(unitId: string) {
    return this.sectionModel.find({ unitId }).sort({ order: 1 });
  }

  // ========== LESSON METHODS ==========
  async createLesson(createLessonDto) {
    const lesson = new this.lessonModel(createLessonDto);
    return lesson.save();
  }

  async updateLesson(id: string, updateData) {
    return this.lessonModel.findByIdAndUpdate(id, updateData, { new: true });
  }

  async deleteLesson(id: string) {
    return this.lessonModel.findByIdAndDelete(id);
  }

  async getLessonsInSection(sectionId: string) {
    return this.lessonModel.find({ sectionId }).sort({ order: 1 });
  }

  // ========== QUIZ QUESTION METHODS ==========
  async addQuizQuestion(lessonId: string, questionDto) {
    const question = new this.quizQuestionModel({
      ...questionDto,
      lessonId,
    });
    return question.save();
  }

  async updateQuizQuestion(id: string, updateData) {
    return this.quizQuestionModel.findByIdAndUpdate(id, updateData, {
      new: true,
    });
  }

  async deleteQuizQuestion(id: string) {
    return this.quizQuestionModel.findByIdAndDelete(id);
  }

  async getQuizQuestions(lessonId: string) {
    return this.quizQuestionModel.find({ lessonId }).sort({ order: 1 });
  }
}
